const router = require('express').Router();
const controller = require('../controllers/taskController');
const requireRole = require('../middleware/requireRole');
router.get('/', controller.list);
router.post('/', requireRole('manager'), controller.create);
router.patch('/:id/status', controller.updateStatus);
router.delete('/:id', requireRole('manager'), controller.remove);
module.exports = router;
