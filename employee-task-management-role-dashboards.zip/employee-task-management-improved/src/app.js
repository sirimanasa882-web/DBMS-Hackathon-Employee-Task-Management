const express = require('express');
const cors = require('cors');
const path = require('path');
const authenticate = require('./middleware/authenticate');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', (req, res) => res.json({ status: 'ok', message: 'Employee Task Management API is running.' }));
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/employees', authenticate, require('./routes/employeeRoutes'));
app.use('/api/projects', authenticate, require('./routes/projectRoutes'));
app.use('/api/tasks', authenticate, require('./routes/taskRoutes'));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Something went wrong. Please try again.' });
});
app.use((req, res) => res.status(404).json({ message: 'Route not found.' }));
module.exports = app;
