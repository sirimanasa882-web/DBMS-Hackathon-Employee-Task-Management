# Employee Task Management System — MySQL edition

## Stack
HTML, CSS, JavaScript, Node.js, Express, MySQL, Sequelize.

## 1. Create database in MySQL Workbench
Run:
```sql
CREATE DATABASE employee_task_db;
```
MySQL Server must be installed and running. MySQL Workbench is the graphical client.

## 2. Configure environment
Copy `.env.example` to `.env`, then set DB_USER and DB_PASSWORD to your MySQL credentials. Default port is 3306.

## 3. Install and run in VS Code terminal
```powershell
npm install
npm run dev
```
Open http://localhost:3000. Health endpoint: http://localhost:3000/api/health.

Sequelize creates Employees, Projects and Tasks tables on startup after connecting to the database.

## APIs
- GET/POST `/api/employees`
- GET/POST `/api/projects`
- GET/POST `/api/tasks`
- PATCH `/api/tasks/:id/status`
- DELETE `/api/tasks/:id`

## Inspect records in MySQL Workbench
```sql
USE employee_task_db;
SHOW TABLES;
SELECT * FROM Employees;
SELECT * FROM Projects;
SELECT * FROM Tasks;
```

This is a starter coursework app. Authentication/JWT and role-based access restrictions are not included yet. Never upload `.env` to GitHub.


## Manager and employee dashboards

New self-registered accounts are employees. To create a manager for a student demo:

1. Register an account through the website.
2. In MySQL Workbench, run (replace the email with that account's email):

```sql
USE employee_task_db;
UPDATE Employees SET role = 'manager' WHERE email = 'manager@example.com';
```

3. Log out and log back in so the new role is included in the login token.

Managers can create projects and tasks and manage employees. Employees only see tasks assigned to their account and can update the status of those tasks. This is a demo setup; in a real deployment, manager creation should be restricted to an administrator.
