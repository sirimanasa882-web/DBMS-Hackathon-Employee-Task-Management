const { Task, Project, Employee } = require('../models');

exports.list = async (req, res) => {
  try {
    const where = {};
    ['status', 'priority', 'projectId', 'assignedTo'].forEach(key => {
      if (req.query[key]) where[key] = req.query[key];
    });
    // Employees can only see tasks assigned to themselves.
    if (req.user.role === 'employee') where.assignedTo = req.user.id;
    const tasks = await Task.findAll({
      where,
      include: [
        { model: Project, as: 'project', attributes: ['id', 'name'] },
        { model: Employee, as: 'assignee', attributes: ['id', 'name', 'email'] }
      ],
      order: [['deadline', 'ASC']]
    });
    res.json(tasks);
  } catch (error) { res.status(500).json({ message: 'Could not load tasks.' }); }
};

exports.create = async (req, res) => {
  try {
    const { title, description, priority, deadline, status, projectId, assignedTo } = req.body;
    if (!title || !String(title).trim()) return res.status(400).json({ message: 'Task title is required.' });
    if (projectId && !await Project.findByPk(projectId)) return res.status(400).json({ message: 'Project not found.' });
    if (assignedTo && !await Employee.findByPk(assignedTo)) return res.status(400).json({ message: 'Employee not found.' });
    const task = await Task.create({ title: String(title).trim(), description, priority, deadline: deadline || null, status, projectId: projectId || null, assignedTo: assignedTo || null });
    res.status(201).json(task);
  } catch (error) { res.status(400).json({ message: error.message }); }
};

exports.updateStatus = async (req, res) => {
  try {
    const allowed = ['pending', 'in_progress', 'completed', 'blocked'];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ message: 'Invalid status.' });
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    // Employees may update status only on their own assigned tasks.
    if (req.user.role === 'employee' && Number(task.assignedTo) !== Number(req.user.id)) {
      return res.status(403).json({ message: 'You can only update tasks assigned to you.' });
    }
    task.status = req.body.status;
    await task.save();
    res.json(task);
  } catch (error) { res.status(500).json({ message: 'Could not update task status.' }); }
};

exports.remove = async (req, res) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    await task.destroy();
    res.json({ message: 'Task deleted successfully.' });
  } catch (error) { res.status(500).json({ message: 'Could not delete task.' }); }
};
