const router = require('express').Router();
const controller = require('../controllers/projectController');
const requireRole = require('../middleware/requireRole');
router.get('/', controller.list);
router.post('/', requireRole('manager'), controller.create);
module.exports = router;
