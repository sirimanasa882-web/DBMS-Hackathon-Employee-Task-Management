const { DataTypes } = require('sequelize');
const db = require('../config/database');
module.exports = db.define('Task', { title: { type: DataTypes.STRING(180), allowNull: false }, description: { type: DataTypes.TEXT }, priority: { type: DataTypes.ENUM('low','medium','high','urgent'), allowNull: false, defaultValue: 'medium' }, deadline: { type: DataTypes.DATEONLY }, status: { type: DataTypes.ENUM('pending','in_progress','completed','blocked'), allowNull: false, defaultValue: 'pending' } });
