const { Employee } = require('../models');
exports.list = async (req,res) => { try { res.json(await Employee.findAll({order:[['name','ASC']]})); } catch(e) { res.status(500).json({message:e.message}); } };
exports.create = async (req,res) => { try { const {name,email,role}=req.body; if(!name||!email) return res.status(400).json({message:'Name and email are required.'}); res.status(201).json(await Employee.create({name,email,role})); } catch(e) { res.status(e.name==='SequelizeUniqueConstraintError'?409:400).json({message:e.message}); } };
