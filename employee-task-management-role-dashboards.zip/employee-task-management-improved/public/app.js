const api = '/api';
const $ = (id) => document.getElementById(id);
let token = localStorage.getItem('taskflow_token');
let currentUser = null;
let employeesCache = [], projectsCache = [], tasksCache = [];

async function call(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(api + path, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401 && token && !path.startsWith('/auth/')) {
    logout(false);
    throw new Error('Your session expired. Please log in again.');
  }
  if (!response.ok) throw new Error(data.message || 'Something went wrong. Please try again.');
  return data;
}
function notify(message, type = 'success', target = 'message') {
  const el = $(target);
  el.textContent = message;
  el.className = `notice ${type}`;
  el.classList.remove('hidden');
  if (target === 'message') {
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => el.classList.add('hidden'), 4500);
  }
}
function showAuthMessage(message, type = 'error') { notify(message, type, 'auth-message'); }
function showLoginTab(which) {
  const login = which === 'login';
  $('login-form').classList.toggle('hidden', !login);
  $('register-form').classList.toggle('hidden', login);
  $('show-login').classList.toggle('active', login);
  $('show-register').classList.toggle('active', !login);
  $('auth-message').classList.add('hidden');
}
$('show-login').onclick = () => showLoginTab('login');
$('show-register').onclick = () => showLoginTab('register');

function setBusy(form, busy) {
  const button = form.querySelector('button[type="submit"]');
  if (!button) return;
  if (busy) { button.dataset.original = button.textContent; button.disabled = true; button.textContent = 'Please wait…'; }
  else { button.disabled = false; if (button.dataset.original) button.textContent = button.dataset.original; }
}
async function authSubmit(formId, endpoint) {
  const form = $(formId);
  form.onsubmit = async (event) => {
    event.preventDefault(); setBusy(form, true);
    const payload = Object.fromEntries(new FormData(form).entries());
    try {
      const result = await call(endpoint, { method: 'POST', body: JSON.stringify(payload) });
      token = result.token; currentUser = result.employee;
      localStorage.setItem('taskflow_token', token);
      form.reset(); showApp();
      notify(result.message || 'Success! You are signed in.');
      await refreshAll();
    } catch (error) { showAuthMessage(error.message); }
    finally { setBusy(form, false); }
  };
}
authSubmit('register-form', '/auth/register');
authSubmit('login-form', '/auth/login');

function logout(showMessage = true) {
  token = null; currentUser = null; localStorage.removeItem('taskflow_token');
  $('app-screen').classList.add('hidden'); $('auth-screen').classList.remove('hidden');
  showLoginTab('login');
  if (showMessage) showAuthMessage('You have been logged out.', 'success');
}
$('logout-btn').onclick = () => logout();
$('top-logout').onclick = () => logout();

function showApp() {
  $('auth-screen').classList.add('hidden'); $('app-screen').classList.remove('hidden');
  const name = currentUser?.name || 'Team member';
  $('sidebar-name').textContent = name;
  $('sidebar-role').textContent = currentUser?.role || 'employee';
  const isManager = currentUser?.role === 'manager';
  $('people').classList.toggle('hidden', !isManager);
  document.querySelectorAll('.manager-only').forEach(el => el.classList.toggle('hidden', !isManager));
  document.querySelectorAll('.manager-nav').forEach(el => el.classList.toggle('hidden', !isManager));
  $('welcome-title').parentElement.querySelector('.subtext').textContent = isManager
    ? 'Manage your people, projects, assignments and deadlines.'
    : 'Here are the tasks assigned to you. Update progress as you work.';
  $('task-panel-heading').textContent = isManager ? 'Task management' : 'My tasks';
  $('task-panel-description').textContent = isManager ? 'Create assignments and monitor team progress.' : 'Track your assigned work and update its status.';
  $('task-toolbar-title').textContent = isManager ? 'All tasks' : 'My assigned tasks';
  $('user-avatar').textContent = name.trim().charAt(0).toUpperCase();
  const hour = new Date().getHours();
  $('welcome-title').textContent = `${hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'}, ${name.split(' ')[0]}`;
}
function fillSelect(id, items, label, emptyLabel, selected = '') {
  const select = $(id); select.innerHTML = '';
  const blank = document.createElement('option'); blank.value = ''; blank.textContent = emptyLabel; select.append(blank);
  items.forEach(item => { const option = document.createElement('option'); option.value = item.id; option.textContent = item[label]; select.append(option); });
  if (items.some(item => String(item.id) === String(selected))) select.value = selected;
}
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function renderEmployees() {
  fillSelect('project-manager', employeesCache.filter(e => e.role === 'manager'), 'name', 'No manager selected');
  fillSelect('task-assignee', employeesCache, 'name', 'Unassigned');
  $('stat-employees').textContent = employeesCache.length;
  $('people-count').textContent = `${employeesCache.length} member${employeesCache.length === 1 ? '' : 's'}`;
  const list = $('employee-list'); list.innerHTML = '';
  if (!employeesCache.length) { list.append(element('p', 'empty-small', 'No team members yet. Add the first employee above.')); return; }
  employeesCache.forEach(employee => {
    const row = element('div', 'person-row');
    row.append(element('div', 'mini-avatar', employee.name.charAt(0).toUpperCase()));
    const details = element('div', 'person-details'); details.append(element('strong', '', employee.name), element('span', '', employee.email));
    row.append(details, element('span', 'role-tag', employee.role)); list.append(row);
  });
}
function renderProjects() {
  fillSelect('task-project', projectsCache, 'name', 'No project');
  $('stat-projects').textContent = projectsCache.length;
  $('project-count').textContent = `${projectsCache.length} project${projectsCache.length === 1 ? '' : 's'}`;
  const list = $('project-list'); list.innerHTML = '';
  if (!projectsCache.length) { list.append(element('p', 'empty-small', 'No projects yet. Create a project above.')); return; }
  projectsCache.forEach(project => {
    const row = element('div', 'project-row');
    const icon = element('div', 'project-icon', '▤');
    const details = element('div', 'person-details'); details.append(element('strong', '', project.name), element('span', '', project.description || 'No description added'));
    row.append(icon, details, element('span', 'count-tag', `${(project.tasks || []).length} tasks`)); list.append(row);
  });
}
function renderTasks() {
  const filter = $('status-filter').value;
  const visible = tasksCache.filter(t => !filter || t.status === filter);
  $('stat-tasks').textContent = tasksCache.length;
  $('stat-completed').textContent = tasksCache.filter(t => t.status === 'completed').length;
  $('task-count').textContent = `${tasksCache.length} task${tasksCache.length === 1 ? '' : 's'}`;
  const list = $('task-list'); list.innerHTML = '';
  if (!visible.length) {
    const empty = element('div', 'empty-state');
    empty.append(element('div', 'empty-icon', '☑'), element('strong', '', filter ? 'No tasks match this filter' : 'Your task list is clear'), element('p', '', filter ? 'Choose another status to see more tasks.' : 'Create your first task using the form above.'));
    list.append(empty); return;
  }
  visible.forEach(task => {
    const card = element('article', 'task-card');
    const main = element('div', 'task-main');
    const titleLine = element('div', 'task-title-line');
    titleLine.append(element('h3', '', task.title), element('span', `priority priority-${task.priority}`, task.priority));
    main.append(titleLine);
    if (task.description) main.append(element('p', 'task-description', task.description));
    const meta = element('div', 'task-meta');
    meta.append(element('span', '', `▤ ${task.project?.name || 'No project'}`), element('span', '', `♙ ${task.assignee?.name || 'Unassigned'}`), element('span', '', `◷ ${task.deadline || 'No deadline'}`));
    main.append(meta);
    const controls = element('div', 'task-controls');
    const status = document.createElement('select'); status.className = `status-select status-${task.status}`;
    [['pending','Pending'],['in_progress','In progress'],['completed','Completed'],['blocked','Blocked']].forEach(([value,label]) => { const opt = document.createElement('option'); opt.value = value; opt.textContent = label; status.append(opt); });
    status.value = task.status;
    status.onchange = async () => {
      try { await call(`/tasks/${task.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: status.value }) }); await loadTasks(); notify('Task status updated successfully.'); }
      catch (error) { notify(error.message, 'error'); }
    };
    const del = element('button', 'icon-btn danger-btn', 'Delete'); del.type = 'button';
    del.onclick = async () => { if (!confirm(`Delete \"${task.title}\"? This cannot be undone.`)) return; try { await call(`/tasks/${task.id}`, { method: 'DELETE' }); await refreshAll(); notify('Task deleted successfully.'); } catch (error) { notify(error.message, 'error'); } };
    controls.append(status);
    if (currentUser?.role === 'manager') controls.append(del);
    card.append(main, controls); list.append(card);
  });
}
async function loadEmployees() { if (currentUser?.role !== 'manager') { employeesCache = []; return; } employeesCache = await call('/employees'); renderEmployees(); }
async function loadProjects() { projectsCache = await call('/projects'); renderProjects(); }
async function loadTasks() { tasksCache = await call('/tasks'); renderTasks(); }
async function refreshAll() { await loadEmployees(); await loadProjects(); await loadTasks(); }

function bindCreateForm(formId, endpoint, successMessage, refresh) {
  const form = $(formId);
  form.onsubmit = async event => {
    event.preventDefault(); setBusy(form, true);
    const data = Object.fromEntries(new FormData(form).entries());
    Object.keys(data).forEach(key => { if (data[key] === '') delete data[key]; });
    try {
      await call(endpoint, { method: 'POST', body: JSON.stringify(data) });
      form.reset(); await refresh(); notify(successMessage);
    } catch (error) { notify(error.message, 'error'); }
    finally { setBusy(form, false); }
  };
}
bindCreateForm('employee-form', '/employees', 'Employee saved successfully in MySQL.', loadEmployees);
bindCreateForm('project-form', '/projects', 'Project created successfully in MySQL.', async () => { await loadProjects(); });
bindCreateForm('task-form', '/tasks', 'Task created successfully in MySQL.', async () => { await loadProjects(); await loadTasks(); });
$('status-filter').onchange = renderTasks;

async function start() {
  if (!token) return;
  try {
    const result = await call('/auth/me');
    currentUser = result.employee; showApp(); await refreshAll();
  } catch (error) {
    logout(false);
    showAuthMessage('Please log in to open your workspace.');
  }
}
start();
