const sequelize = require('../config/database');
const Employee = require('./Employee'); const Project = require('./Project'); const Task = require('./Task');
Employee.hasMany(Project, { as: 'managedProjects', foreignKey: 'managerId' }); Project.belongsTo(Employee, { as: 'manager', foreignKey: 'managerId' });
Project.hasMany(Task, { as: 'tasks', foreignKey: 'projectId' }); Task.belongsTo(Project, { as: 'project', foreignKey: 'projectId' });
Employee.hasMany(Task, { as: 'assignedTasks', foreignKey: 'assignedTo' }); Task.belongsTo(Employee, { as: 'assignee', foreignKey: 'assignedTo' });
module.exports = { sequelize, Employee, Project, Task };
