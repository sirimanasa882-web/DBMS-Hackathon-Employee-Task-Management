const { DataTypes } = require('sequelize');
const db = require('../config/database');

module.exports = db.define('Employee', {
  name: { type: DataTypes.STRING(100), allowNull: false },
  email: { type: DataTypes.STRING(150), allowNull: false, unique: true, validate: { isEmail: true } },
  passwordHash: { type: DataTypes.STRING(255), allowNull: true, field: 'password_hash' },
  role: { type: DataTypes.ENUM('manager', 'employee'), allowNull: false, defaultValue: 'employee' }
});
