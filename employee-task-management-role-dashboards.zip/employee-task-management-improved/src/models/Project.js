const { DataTypes } = require('sequelize');
const db = require('../config/database');
module.exports = db.define('Project', { name: { type: DataTypes.STRING(150), allowNull: false }, description: { type: DataTypes.TEXT } });
