const router = require('express').Router();
const controller = require('../controllers/employeeController');
const requireRole = require('../middleware/requireRole');
router.get('/', requireRole('manager'), controller.list);
router.post('/', requireRole('manager'), controller.create);
module.exports = router;
