const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Employee } = require('../models');

function makeToken(employee) {
  return jwt.sign(
    { id: employee.id, name: employee.name, email: employee.email, role: employee.role },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
}
function safeEmployee(employee) {
  return { id: employee.id, name: employee.name, email: employee.email, role: employee.role };
}

exports.register = async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required.' });
    if (password.length < 8) return res.status(400).json({ message: 'Password must be at least 8 characters.' });
    const existing = await Employee.findOne({ where: { email } });
    const passwordHash = await bcrypt.hash(password, 12);
    let employee;
    if (existing) {
      if (existing.passwordHash) return res.status(409).json({ message: 'An account with this email already exists. Please log in.' });
      // An employee may have been added earlier by the manager. Activate that record
      // instead of creating a duplicate, preserving its assigned role.
      existing.name = name;
      existing.passwordHash = passwordHash;
      await existing.save();
      employee = existing;
    } else {
      employee = await Employee.create({ name, email, passwordHash, role: 'employee' });
    }
    return res.status(201).json({ message: 'Registration successful! You are now logged in.', token: makeToken(employee), employee: safeEmployee(employee) });
  } catch (e) {
    return res.status(400).json({ message: 'Could not register. Check the details and try again.' });
  }
};

exports.login = async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) return res.status(400).json({ message: 'Enter your email and password.' });
    const employee = await Employee.findOne({ where: { email } });
    if (!employee || !employee.passwordHash || !(await bcrypt.compare(password, employee.passwordHash))) {
      return res.status(401).json({ message: 'Email or password is incorrect. If you were added by a manager, register an account using this email only if your account has not been activated.' });
    }
    return res.json({ message: 'Login successful. Welcome back!', token: makeToken(employee), employee: safeEmployee(employee) });
  } catch (e) {
    return res.status(500).json({ message: 'Unable to log in right now.' });
  }
};

exports.me = async (req, res) => {
  const employee = await Employee.findByPk(req.user.id);
  if (!employee) return res.status(404).json({ message: 'Account not found.' });
  res.json({ employee: safeEmployee(employee) });
};
